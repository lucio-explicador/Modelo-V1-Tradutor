// ═══════════════════════════════════════════════
// DICIONÁRIO — Xichangana ↔ Português
// DakiPraKi · thynkOS
// Para adicionar entradas: { ch: "palavra", pt: "tradução" }
// ═══════════════════════════════════════════════

const DICT = [
  // ── A ─────────────────────────────────────
  { ch: "Á Kóla Ní Kóla",       pt: "Rápido, Instantâneo" },
  { ch: "Á Kúpfúléka",          pt: "Aberto" },
  { ch: "Á Kutálá",             pt: "Superlotado" },
  { ch: "á Kúyíla",             pt: "Obsceno, Imoral" },
  { ch: "Á Le Kusúhisúhi",      pt: "Imediato, Próximo" },
  { ch: "Á muvála wá vhínyu",   pt: "Violeta" },
  { ch: "á Nkanú",              pt: "Teimosia" },
  { ch: "Á Vúthlélájámbu",      pt: "Tropical" },
  { ch: "Á Vutswáná",           pt: "Tsuana" },
  { ch: "Á xáka",               pt: "Parente" },
  { ch: "Adéptu",               pt: "Adepto" },
  { ch: "Ahánti",               pt: "Talvez" },
  { ch: "Ahée",                 pt: "Cuidado" },
  { ch: "Ahihim",               pt: "Não" },
  { ch: "Áká",                  pt: "Construir, Morar" },
  { ch: "Ála",                  pt: "Recusar, Negar" },
  { ch: "Ani",                  pt: "Não" },
  { ch: "Anyikile",             pt: "Deu, Entregou" },
  { ch: "Árixéni",              pt: "Bom-dia" },
  { ch: "Auxene",               pt: "Bom dia" },
  { ch: "auxeni",               pt: "Bom dia" },
  { ch: "Aupeleni",             pt: "Boa noite" },
  { ch: "Ásvíféni",             pt: "Parabéns" },
  { ch: "Áwée",                 pt: "Bonito, Aprovação" },
  // ── B ─────────────────────────────────────
  { ch: "Bábaláza",             pt: "Ressaca" },
  { ch: "Bafadóri",             pt: "Berlinde" },
  { ch: "Bakáta",               pt: "Abacate" },
  { ch: "Bándi",                pt: "Cinto" },
  { ch: "Basa",                 pt: "Limpo, Puro" },
  { ch: "Baséla",               pt: "Brinde, Bónus" },
  { ch: "Bikiri",               pt: "Caneca" },
  { ch: "Bóhá",                 pt: "Amarrar, Atar" },
  { ch: "Boti",                 pt: "Barco" },
  { ch: "Bóxá",                 pt: "Furar, Abrir" },
  { ch: "Búku",                 pt: "Livro" },
  { ch: "Bulúku",               pt: "Calça" },
  { ch: "Búlukwá",              pt: "Pipoca, Calças" },
  { ch: "Bzanyi",               pt: "Capim, Relva" },
  // ── C ─────────────────────────────────────
  { ch: "Chayisa",              pt: "Atropelar" },
  // ── D ─────────────────────────────────────
  { ch: "Damarhela",            pt: "Lagartixa" },
  { ch: "Dokodela",             pt: "Médico" },
  { ch: "Dumba-nengue",         pt: "Mercado informal" },
  { ch: "Dúvúlá",              pt: "Atirar" },
  { ch: "dzaha",                pt: "Fumar" },
  { ch: "Dzana",                pt: "Cem" },
  { ch: "Dzedzedze",            pt: "Malária" },
  { ch: "dzampfi",              pt: "Idiota" },
  // ── F ─────────────────────────────────────
  { ch: "Fambani",              pt: "Adeus" },
  // ── H ─────────────────────────────────────
  { ch: "Hambanine",            pt: "Tchau" },
  { ch: "Hina",                 pt: "Nós" },
  { ch: "huku",                 pt: "Galinha" },
  // ── I ─────────────────────────────────────
  { ch: "I hlikani",            pt: "Boa tarde" },
  { ch: "Ina",                  pt: "Nome" },
  // ── K ─────────────────────────────────────
  { ch: "Ka Hissa",             pt: "Está quente" },
  { ch: "Kanimambo",            pt: "Obrigado" },
  { ch: "kokwana",              pt: "Avô" },
  // ── L ─────────────────────────────────────
  { ch: "Lembe",                pt: "Ano" },
  { ch: "Lichile",              pt: "Bom dia" },
  { ch: "Lipelile",             pt: "Boa noite" },
  // ── M ─────────────────────────────────────
  { ch: "Mahala",               pt: "Grátis" },
  { ch: "mati",                 pt: "Água" },
  { ch: "mbuti",                pt: "Cabrito" },
  { ch: "Mina",                 pt: "Eu" },
  { ch: "mina ni lava wene",    pt: "Eu te quero" },
  { ch: "Mpfumo",               pt: "Chefe" },
  { ch: "mundzuku",             pt: "Até amanhã" },
  { ch: "murandziwa",           pt: "Meu amor" },
  { ch: "Mwina",                pt: "Vós" },
  // ── N ─────────────────────────────────────
  { ch: "Ndhawu",               pt: "Lugar" },
  { ch: "Nhluvukiso",           pt: "Desenvolvimento" },
  { ch: "Nilava Male",          pt: "Quero dinheiro" },
  { ch: "Nilava Wena",          pt: "Quero você" },
  { ch: "Nirivalele",           pt: "Desculpa" },
  { ch: "Nkarhi",               pt: "Hora" },
  { ch: "Ntlawa",               pt: "Grupo" },
  { ch: "ntamu ligarela",       pt: "Vou te ligar" },
  { ch: "no kombela mati",      pt: "Estou a pedir água" },
  { ch: "no tsala",             pt: "Estou a escrever" },
  { ch: "Nyanga",               pt: "Mês" },
  // ── P ─────────────────────────────────────
  { ch: "pfuka",                pt: "Acorda" },
  // ── S ─────────────────────────────────────
  { ch: "Siku",                 pt: "Dia" },
  { ch: "suka lano",            pt: "Sai daqui" },
  { ch: "swoswi",               pt: "Agora" },
  // ── T ─────────────────────────────────────
  { ch: "Tiko",                 pt: "País" },
  { ch: "tsala",                pt: "Escrever" },
  { ch: "txela mati",           pt: "Encher água" },
  // ── V ─────────────────────────────────────
  { ch: "Vona",                 pt: "Eles" },
  { ch: "Vuhosi",               pt: "Realeza" },
  // ── W ─────────────────────────────────────
  { ch: "Wena",                 pt: "Tu" },
  // ── X ─────────────────────────────────────
  { ch: "Xá Dula",              pt: "Está caro" },
  { ch: "xibhakitana",          pt: "Bacia" },
  { ch: "xifalo",               pt: "Porta" },
  { ch: "Xihatla",              pt: "Língua" },
  { ch: "Xikomu",               pt: "Governo" },
  // ── Y ─────────────────────────────────────
  { ch: "Yena",                 pt: "Ele" },
];

// ── Constrói os mapas bidirecionais ─────────
(function() {
  function norm(s) {
    if (!s) return "";
    return s.toLowerCase()
      .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
      .replace(/[^\w\s]/g, "").replace(/\s+/g, " ").trim();
  }

  window.DICT      = DICT;
  window.PT_TO_CH  = new Map();
  window.CH_TO_PT  = new Map();

  DICT.forEach(e => {
    window.PT_TO_CH.set(norm(e.pt), e.ch);
    window.CH_TO_PT.set(norm(e.ch), e.pt);
    // Mapeia também traduções com vírgula individualmente (ex: "Rápido" → ch)
    e.pt.split(",").forEach(p => {
      const k = norm(p.trim());
      if (k) window.PT_TO_CH.set(k, e.ch);
    });
  });

  window.DICT_COUNT = DICT.length;
})();
