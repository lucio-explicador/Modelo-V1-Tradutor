// ═══════════════════════════════════════════════
// DakiPraKi — App Logic
// thynkOS · 2025
// ═══════════════════════════════════════════════

document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("dict-count").textContent = window.DICT_COUNT + " entradas";
});

const App = {
  dir:         "pt-ch",
  timer:       null,
  recognition: null,
  recording:   false,

  // ── Normalização ──────────────────────────
  norm(s) {
    if (!s) return "";
    return s.toLowerCase()
      .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
      .replace(/[^\w\s]/g, "").replace(/\s+/g, " ").trim();
  },

  esc(s) {
    return String(s)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  },

  // ── Direcção ──────────────────────────────
  setDir(d) {
    this.dir = d;
    const isPt = d === "pt-ch";
    document.getElementById("btn-pt").classList.toggle("active",  isPt);
    document.getElementById("btn-ch").classList.toggle("active", !isPt);
    document.getElementById("lbl-src").textContent = isPt ? "Português"  : "Xichangana";
    document.getElementById("lbl-tgt").textContent = isPt ? "Xichangana" : "Português";
    document.getElementById("inp").placeholder = isPt
      ? "Fale ou escreva aqui em Português..."
      : "Fale ou escreva aqui em Xichangana...";
    this.clear();
  },

  swap() {
    this.setDir(this.dir === "pt-ch" ? "ch-pt" : "pt-ch");
  },

  // ── Input ─────────────────────────────────
  onInput() {
    clearTimeout(this.timer);
    this.timer = setTimeout(() => this.translate(document.getElementById("inp").value), 55);
  },

  // ── Tradução ──────────────────────────────
  translate(text) {
    const out = document.getElementById("out");
    if (!text.trim()) {
      out.innerHTML = '<span class="placeholder">A tradução aparecerá aqui...</span>';
      return;
    }

    const map   = this.dir === "pt-ch" ? window.PT_TO_CH : window.CH_TO_PT;
    const regex = /([\wáçéíóúãõâêîôûàèìòùäëïöüñ]+)|([^a-zA-Záçéíóúãõâêîôûàèìòùäëïöüñ\s]+)|(\s+)/gi;
    const tokens = text.match(regex) || [];
    let html = "", i = 0;

    while (i < tokens.length) {
      let matched = 0, translated = null;

      // Tenta frases longas primeiro (greedy)
      for (let j = tokens.length; j > i; j--) {
        const phrase = this.norm(tokens.slice(i, j).join(""));
        if (phrase && map.has(phrase)) {
          matched    = j - i;
          translated = map.get(phrase);
          break;
        }
      }

      if (matched > 0) {
        html += `<span class="token translated">${this.esc(translated)}</span>`;
        i += matched;
      } else {
        const t = tokens[i];
        html += /[\wáçéíóúãõâêîôûàèìòùäëïöüñ]/i.test(t)
          ? `<span class="token untranslated" title="Não encontrado no dicionário">${this.esc(t)}</span>`
          : this.esc(t);
        i++;
      }
    }

    out.innerHTML = html;
  },

  clear() {
    document.getElementById("inp").value = "";
    this.translate("");
    document.getElementById("inp").focus();
  },

  // ── TTS ───────────────────────────────────
  speak(text, btnId) {
    if (!text || !window.speechSynthesis) return;
    window.speechSynthesis.cancel();
    const u   = new SpeechSynthesisUtterance(text);
    u.lang    = "pt-MZ";
    u.rate    = 0.88;
    const btn = document.getElementById(btnId);
    if (btn) {
      btn.classList.add("speaking");
      u.onend = u.onerror = () => btn.classList.remove("speaking");
    }
    window.speechSynthesis.speak(u);
  },

  speakSrc() {
    const t = document.getElementById("inp").value;
    if (t.trim()) this.speak(t, "btn-speak-src");
  },

  speakTgt() {
    const t = document.getElementById("out").innerText;
    if (t && !t.includes("aparecerá")) this.speak(t, "btn-speak-tgt");
  },

  // ── Copy ──────────────────────────────────
  copy() {
    const t = document.getElementById("out").innerText;
    if (!t || t.includes("aparecerá")) return;
    navigator.clipboard.writeText(t).then(() => {
      const btn = document.getElementById("btn-copy");
      btn.classList.add("ok");
      btn.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>`;
      setTimeout(() => {
        btn.classList.remove("ok");
        btn.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>`;
      }, 1600);
    });
  },

  // ── STT Microfone ─────────────────────────
  toggleMic() {
    this.recording ? this.stopMic() : this.startMic();
  },

  startMic() {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) { alert("Reconhecimento de voz não suportado neste browser."); return; }

    this.recognition                  = new SR();
    this.recognition.lang             = "pt-MZ";
    this.recognition.continuous       = true;
    this.recognition.interimResults   = true;

    this.recognition.onstart = () => {
      this.recording = true;
      document.getElementById("btn-mic").classList.add("on");
      document.getElementById("live-badge").classList.add("active");
      document.getElementById("inp").placeholder = "A ouvir...";
    };

    this.recognition.onresult = (e) => {
      let final = "", interim = "";
      for (let i = e.resultIndex; i < e.results.length; i++) {
        if (e.results[i].isFinal) final  += e.results[i][0].transcript;
        else                      interim += e.results[i][0].transcript;
      }
      const inp = document.getElementById("inp");
      if (final) {
        inp.value += (inp.value.length > 0 ? " " : "") + final;
        this.onInput();
      }
      const el = document.getElementById("interim");
      el.textContent = interim;
      interim ? el.classList.add("on") : el.classList.remove("on");
    };

    this.recognition.onerror = (e) => {
      if (e.error === "not-allowed") alert("Acesso ao microfone negado. Verifica as permissões do browser.");
      this.stopMic();
    };

    this.recognition.onend = () => {
      if (this.recording) {
        try { this.recognition.start(); } catch (err) { this.stopMic(); }
      }
    };

    try { this.recognition.start(); } catch (e) { console.error(e); }
  },

  stopMic() {
    this.recording = false;
    if (this.recognition) { try { this.recognition.stop(); } catch (e) {} }
    document.getElementById("btn-mic").classList.remove("on");
    document.getElementById("live-badge").classList.remove("active");
    document.getElementById("inp").placeholder = this.dir === "pt-ch"
      ? "Fale ou escreva aqui em Português..."
      : "Fale ou escreva aqui em Xichangana...";
    const el = document.getElementById("interim");
    el.textContent = ""; el.classList.remove("on");
  },

  // ── Scroll reveal ─────────────────────────
  initReveal() {
    const obs = new IntersectionObserver((entries) => {
      entries.forEach((e, i) => {
        if (e.isIntersecting) {
          setTimeout(() => e.target.classList.add("visible"), i * 140);
          obs.unobserve(e.target);
        }
      });
    }, { threshold: 0.18 });
    document.querySelectorAll("[data-reveal]").forEach(el => obs.observe(el));
  },
};

App.initReveal();
